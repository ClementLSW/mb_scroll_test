﻿import { TypeStore } from "@needle-tools/engine"

// Import types
import { ScollTimeline } from "../scripts/MBScrollTimeline";
import { ScrollTimeline_2 } from "../scripts/MBScrollTimeline_2";

// Register types
TypeStore.add("ScollTimeline", ScollTimeline);
TypeStore.add("ScrollTimeline_2", ScrollTimeline_2);
